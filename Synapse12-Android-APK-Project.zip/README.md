# Synapse 12 Android APK Project

This Android Studio project wraps the configured Synapse 12 web app into a native Android APK shell.

Included:
- Firebase configuration already inside the web app
- Real-time rooms/chat/progress
- Physics, Chemistry, Maths and Biology syllabus
- Anonymous Firebase auth
- Portrait mobile layout

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install `app/build/outputs/apk/debug/app-debug.apk`.

The web app still uses Firebase over the internet, so the phone needs an internet connection.
