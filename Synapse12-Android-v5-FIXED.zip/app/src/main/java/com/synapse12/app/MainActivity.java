package com.synapse12.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.InputStream;

public class MainActivity extends Activity {
    WebView webView;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        try {
            InputStream in = getAssets().open("index.html");
            byte[] bytes = new byte[in.available()];
            int read = in.read(bytes);
            in.close();
            String html = new String(bytes, "UTF-8");
            // Give the local page a secure HTTPS origin so Firebase's ES modules/auth
            // work inside Android WebView instead of loading from file://.
            webView.loadDataWithBaseURL(
                "https://synapse-12.web.app/",
                html,
                "text/html",
                "UTF-8",
                "https://synapse-12.web.app/"
            );
        } catch (Exception e) {
            webView.loadUrl("https://synapse-12.web.app/");
        }
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript(
            "(function(){var m=document.getElementById('modal'); if(m && !m.classList.contains('hidden')){ if(window.closeModal){window.closeModal();return true;} } return false;})()",
            value -> {
                if (!"true".equals(value) && webView.canGoBack()) webView.goBack();
                else if (!"true".equals(value)) super.onBackPressed();
            }
        );
    }
}
