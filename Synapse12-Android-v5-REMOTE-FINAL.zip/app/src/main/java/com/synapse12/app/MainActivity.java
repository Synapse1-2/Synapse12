package com.synapse12.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebChromeClient; import android.webkit.WebSettings; import android.webkit.WebView; import android.webkit.WebViewClient;
public class MainActivity extends Activity {
 WebView webView;
 public void onCreate(Bundle b){super.onCreate(b); webView=new WebView(this); setContentView(webView); WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient()); webView.loadUrl("https://synapse-12.web.app/");}
 @Override public void onBackPressed(){webView.evaluateJavascript("(function(){var m=document.getElementById('modal'); if(m && !m.classList.contains('hidden')){ if(window.closeModal){window.closeModal();return true;} } return false;})()", value -> { if (!"true".equals(value) && webView.canGoBack()) webView.goBack(); else if (!"true".equals(value)) super.onBackPressed(); });}
}
