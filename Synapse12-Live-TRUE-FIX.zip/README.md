# Synapse 12 Live

A real-time collaborative Class 12 study-room web app for 2–6 students. It includes:
- private room code + invite flow
- real-time syllabus tracker
- shared notes
- dedicated room chat
- shared goals/deadlines
- cloud diagram/image vault
- shared Pomodoro/focus session log
- dashboard + member list
- Firebase Authentication (anonymous), Firestore and Storage

## 1. Create Firebase project
1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web App and copy its `firebaseConfig` object.
3. Enable Authentication → Sign-in method → Anonymous.
4. Create Cloud Firestore database.
5. Create Cloud Storage.

## 2. Configure the app
Open `index.html` and replace the `firebaseConfig` values near the top of the module script with your Firebase web-app config.

For the Storage bucket, use exactly the bucket value Firebase gives your web app. Newer Firebase projects may use a `*.firebasestorage.app` bucket name.

## 3. Deploy
Install the Firebase CLI, then from this folder run:

```bash
firebase login
firebase use --add
firebase deploy
```

When prompted by `firebase use --add`, choose the Firebase project you created.

Firebase Hosting will give you a public `web.app` URL. Share that URL with your friends. Create a room inside Synapse 12 and send them the room code.

## 4. Security note
The included Firestore/Storage rules require Firebase Authentication and restrict app data to room members. The app currently uses anonymous accounts for easy entry. If you later want permanent accounts, add Google/email authentication and link anonymous accounts to them.

## 5. Important
Do not publish Firestore in open/test mode for production. Deploy the included rules.

## v2 syllabus update
- RBSE Class 12 2026–27 syllabus tracker now has four separate compartments: Physics, Chemistry, Maths, Biology.
- Each subject has its chapter list plus expandable detailed topics.
- Existing chapter-stage progress is preserved when an older room opens the new app (syllabus version migration).
- Biology has 13 Class 12 chapters.
- The Firebase configuration is already included in this package.
