# Synapse 12 MASTER Android

This Android shell loads the live Synapse 12 web app over HTTPS, avoiding local-file Firebase Auth origin problems. The live web app contains the consolidated V1–V5 MASTER build.
