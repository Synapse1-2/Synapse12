# Synapse 12 MASTER

Master consolidation of Synapse 12 V1–V5.

## Included
- V1 foundation: rooms, chat, dashboard, notes, goals, diagrams, timer, Firebase sync
- V2/V3: detailed RBSE Class 12 syllabus, Biology, progress migration, compressed image sharing
- V4: modal Back button, backdrop close, browser history back, Android back compatibility
- V5: premium dashboard, dark/light theme, mobile navigation, Smart Planner, Quick Quiz, Study Assistant, Analytics, XP/Streaks/Achievements, Vijay branding and @pls_vijay
- MASTER reliability: app UI is never blocked by Firebase Auth; cloud sync connects in the background and offline mode remains usable.

## Firebase
Uses the existing `synapse-12` Firebase project. No Firebase Storage billing is required for diagram sharing; images are compressed client-side and stored in Firestore.
