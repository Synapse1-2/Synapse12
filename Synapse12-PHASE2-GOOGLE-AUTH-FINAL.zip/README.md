# Synapse 12 — Phase 1 Web

Phase 1 upgrades the existing working MASTER web app without changing the Firebase project, Firestore rules, authentication model, room/chat/notes/goals/diagrams/timer foundations, or Android project.

## Phase 1 modules
- Smart Planner: uses available minutes, syllabus stage progress, open goals, priority and block length; saves the latest plan locally; plan items can launch the timer.
- Quick Quiz: generates a 5-question syllabus-based MCQ set from the stored chapter/topic data, records a score and lets the student retry.
- Analytics: shows focus time, syllabus completion, sessions, goals completed, subject progress and recent focus sessions.

## Validation performed
- JavaScript syntax check passed with Node.js `node --check`.
- Existing Firebase/room/auth code was retained.
- Existing app remains client-side and uses the same Firebase project configuration.


## Phase 2 — Gamification

- Account/browser-scoped XP ledger with duplicate-event protection.
- XP from focus sessions, syllabus stages, quizzes, and completed goals.
- Level progression every 250 XP with Starter, Focused, Scholar, and Legend ranks.
- Consecutive-day study streak tracking.
- Eight achievements with unlock states and progress details.
- Existing Phase 1 Smart Planner, Quiz, Analytics, Timer, Syllabus, Rooms, Notes, Chat, Goals, and Diagrams preserved.
- Gamification state is stored locally and keyed to the authenticated anonymous user when available.
