# Synapse 12 — Phase 1 Build

Developer: **Vijay** ([@pls_vijay](https://instagram.com/pls_vijay))

## ✅ What's working in this build

- **Auth**: Google Sign-In via Firebase, no infinite "Connecting…" screen
  (6-second timeout auto-offers "Continue offline"), real error messages
  surfaced, offline/local mode if Firebase is unreachable.
- **Dashboard**: XP, level, streak, focus time, syllabus %, active goals,
  smart recommendation — all real, computed from actual state.
- **Syllabus**: Physics / Chemistry / Maths / Biology, full NCERT-based
  chapter lists, 5-stage tracking (Theory → Derivation → Examples → PYQ →
  Revision), search, subject/chapter/overall %. Progress is keyed by a
  stable `subject_chapter` id so future syllabus edits won't wipe progress.
- **Smart Planner**: 3 real modes (Weakest Subject, Goals First, Balanced),
  25/50-min blocks, picks an actual next chapter+stage and explains why.
- **"What should I study?"**: same engine, shown on the Dashboard and
  Assistant tab.
- **Goals**: create / complete / delete, priority, XP on completion.
- **Focus Timer**: personal Pomodoro-style session, awards XP, logs to
  analytics, updates streak.
- **Quick Quiz**: 5 syllabus-based MCQs, scoring, XP (10 base + 10/correct,
  60 for 5/5), resets cleanly on retry, cannot double-award XP.
- **XP / Levels**: Starter → Focused → Scholar → Legend, with a hard
  anti-duplicate log (`state.xpLog`) — every award needs a unique
  `sourceKey`, so re-renders/reloads can never double-pay XP.
- **Streak**: first day = 1, consecutive = +1, missed day resets, same-day
  activity never double-counts.
- **Dark/Light mode**, persisted, all components themed.
- **Mobile bottom nav + desktop sidebar**, responsive down to small phones.
- **Modals**: Escape key, outside-tap, and Browser Back all close a modal
  correctly, with no history-entry buildup.
- **Local persistence** is the source of truth for instant UI; Firestore
  syncs in the background (debounced) and never blocks anything.

## 🚧 Not built yet (Phase 2/3 — next)

- Rooms (create/join, 6-member cap, presence, owner permissions)
- Real-time WhatsApp-style chat
- Collaborative Pomodoro ("who's studying now")
- Shared image/diagram board
- Collaborative notes
- Achievements (unlock conditions + UI)
- Android WebView wrapper + back-button handling + APK

None of these are faked or stubbed with dead buttons — they simply aren't
in this delivery yet, per the "no fake functionality" rule.

## Setup

1. Copy this folder into your `Synapse1-2/Synapse12` repo (replacing web
   files, keeping `.git`).
2. In Firebase Console → Authentication → enable **Google** sign-in
   provider, and add your deployed domain (and `localhost` for testing)
   to **Authorized domains**.
3. Deploy Firestore rules:
   ```
   firebase deploy --only firestore:rules
   ```
   (`firestore.rules` in this folder — authenticated-users-only, no
   wildcard `allow read, write: if true`, and already scaffolded for
   Phase 3 rooms so rules won't need weakening later.)
4. Deploy hosting:
   ```
   firebase deploy --only hosting
   ```
5. Test on `synapse-12.web.app` — Google login, syllabus checkboxes,
   planner, quiz, goals, focus timer, dark/light toggle, and mobile view.

## Notes on implementation choices

- **No ES modules** — plain `<script>` tags + Firebase **compat** SDK.
  Your own bug list flags "import statements mid-file" and "onclick
  unavailable due to module scope" — compat SDK avoids both entirely.
- **No Blaze required** — everything here runs on Firestore + Auth only,
  well within the free Spark plan.
