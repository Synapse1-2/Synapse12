/* SYNAPSE 12 — Analytics
   Every number here is derived from real state. Nothing is randomly
   generated or hardcoded, per the "No Fake Functionality" rule.
*/

function getAnalyticsSnapshot() {
  const totalFocusMinutes = state.focusSessions.reduce((sum, s) => sum + s.minutes, 0);
  const totalSessions = state.focusSessions.length;
  const completedGoals = state.goals.filter((g) => g.status === "completed").length;
  const overallSyllabusPct = getOverallProgressPct(state.syllabusProgress);

  const subjectBreakdown = Object.keys(SYLLABUS).map((subject) => ({
    subject,
    icon: SYLLABUS[subject].icon,
    pct: getSubjectProgressPct(subject, state.syllabusProgress)
  }));

  const recentSessions = [...state.focusSessions]
    .sort((a, b) => b.completedAt - a.completedAt)
    .slice(0, 5);

  const recentQuizzes = [...state.quizHistory]
    .sort((a, b) => b.completedAt - a.completedAt)
    .slice(0, 5);

  return {
    totalFocusMinutes,
    totalSessions,
    completedGoals,
    overallSyllabusPct,
    subjectBreakdown,
    recentSessions,
    recentQuizzes,
    xp: state.xp,
    level: computeLevel(state.xp),
    streak: state.streak.count
  };
}
