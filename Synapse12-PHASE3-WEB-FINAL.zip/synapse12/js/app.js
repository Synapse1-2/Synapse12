/* SYNAPSE 12 — App Orchestrator
   Startup sequence follows the spec exactly:
   1. Render UI (index.html does this instantly, before any JS runs)
   2. Initialize Firebase
   3. Initialize Google Auth
   4. Restore user
   5. (Room connect — Phase 3)
   6. (Online status — Phase 3)
   If Firebase fails at any point, local features must still work.
*/

let currentSectionId = "dashboard";

document.addEventListener("DOMContentLoaded", () => {
  loadLocalState();
  applyTheme(state.theme);

  document.addEventListener("firebase-ready", () => {
    document.getElementById("auth-status-line").textContent = "Ready";
    watchAuthState();
  });

  document.addEventListener("firebase-error", () => {
    document.getElementById("auth-status-line").innerHTML =
      "Couldn't connect to Firebase. Check your connection, or " +
      '<a href="#" onclick="continueOffline();return false;">continue offline</a>.';
  });

  document.addEventListener("state-updated", () => renderCurrentSection(currentSectionId));
  document.addEventListener("focus-tick", updateFocusModalDisplay);
  document.addEventListener("focus-started", updateFocusModalDisplay);
  document.addEventListener("focus-completed", (e) => {
    closeModal("modal-focus");
    showToast(`Session complete — ${e.detail.minutes} min logged`, "success");
  });

  initFirebase();

  // Safety net: never let the user stare at "Connecting…" forever.
  setTimeout(() => {
    if (!firebaseReady) {
      document.getElementById("auth-status-line").innerHTML =
        "Taking longer than usual. " +
        '<a href="#" onclick="continueOffline();return false;">Continue offline</a> instead?';
    }
  }, 6000);
});

function continueOffline() {
  loadLocalState();
  showAppScreen();
  renderCurrentSection("dashboard");
  showToast("Working offline — sign in later to sync", "warn");
}

function showAuthScreen() {
  document.getElementById("auth-screen").style.display = "flex";
  document.getElementById("app-shell").style.display = "none";
}

function showAppScreen() {
  document.getElementById("auth-screen").style.display = "none";
  document.getElementById("app-shell").style.display = "flex";
}

function setActiveSectionTitle(sectionId) {
  const titles = {
    dashboard: "Dashboard", planner: "Smart Planner", syllabus: "Syllabus",
    goals: "Goals", room: "Study Room", quiz: "Quick Quiz", analytics: "Analytics", assistant: "Study Assistant"
  };
  document.getElementById("topbar-title").textContent = titles[sectionId] || "Synapse 12";
}

function renderCurrentSection(sectionId) {
  currentSectionId = sectionId || currentSectionId;
  setActiveSectionTitle(currentSectionId);
  const renderers = {
    dashboard: renderDashboard, planner: renderPlanner, syllabus: renderSyllabus,
    goals: renderGoals, room: renderRoom, quiz: renderQuiz, analytics: renderAnalytics, assistant: renderAssistant
  };
  const fn = renderers[currentSectionId];
  if (fn) fn();
}

/* ============ DASHBOARD ============ */
function renderDashboard() {
  const el = document.getElementById("section-dashboard");
  const a = getAnalyticsSnapshot();
  const rec = getStudyRecommendation(25);

  el.innerHTML = `
    <div class="grid-bento">
      <div class="card card-wide card-hero">
        <p class="eyebrow-free">Welcome back</p>
        <h2>${a.overallSyllabusPct}% through your syllabus</h2>
        <div class="progress-bar"><div class="progress-fill" style="width:${a.overallSyllabusPct}%"></div></div>
      </div>

      <div class="card card-stat">
        <span class="stat-label">XP</span>
        <span class="stat-value">${a.xp}</span>
        <span class="stat-sub">${a.level.name}</span>
      </div>

      <div class="card card-stat">
        <span class="stat-label">Streak</span>
        <span class="stat-value">🔥 ${a.streak}</span>
        <span class="stat-sub">day${a.streak === 1 ? "" : "s"}</span>
      </div>

      <div class="card card-stat">
        <span class="stat-label">Focus Time</span>
        <span class="stat-value">${a.totalFocusMinutes}m</span>
        <span class="stat-sub">${a.totalSessions} sessions</span>
      </div>

      <div class="card card-wide">
        <p class="eyebrow-free">What should I study?</p>
        ${rec.empty ? `<p>${rec.message}</p>` : `
          <h3>${rec.subject} — ${rec.chapterName}</h3>
          <p class="muted">Stage: ${STAGE_LABELS[rec.stage]} · ${rec.reason}</p>
          <button class="btn-primary" onclick="handleStartFocusFromRec('${rec.subject}','${rec.chapterId}','${rec.stage}')">Start 25 min session</button>
        `}
      </div>

      <div class="card card-wide">
        <p class="eyebrow-free">Active Goals</p>
        ${renderGoalListMini(getActiveGoals())}
      </div>
    </div>
  `;
}

function renderGoalListMini(goals) {
  if (!goals.length) return `<p class="muted">No active goals yet. Add one from the Goals tab.</p>`;
  return `<ul class="mini-list">${goals.slice(0, 4).map((g) => `
    <li><span class="priority-dot priority-${g.priority}"></span>${g.title}</li>
  `).join("")}</ul>`;
}

/* ============ PLANNER ============ */
let plannerMode = "balanced";
let plannerMinutes = 25;

function renderPlanner() {
  const el = document.getElementById("section-planner");
  const plan = state.plannerLastPlan;

  el.innerHTML = `
    <div class="card card-wide">
      <p class="eyebrow-free">Available time</p>
      <div class="chip-row">
        <button class="chip ${plannerMinutes === 25 ? "chip-active" : ""}" onclick="setPlannerMinutes(25)">25 min</button>
        <button class="chip ${plannerMinutes === 50 ? "chip-active" : ""}" onclick="setPlannerMinutes(50)">50 min</button>
      </div>
      <p class="eyebrow-free" style="margin-top:16px;">Mode</p>
      <div class="chip-row">
        <button class="chip ${plannerMode === "weakest" ? "chip-active" : ""}" onclick="setPlannerMode('weakest')">Weakest Subject</button>
        <button class="chip ${plannerMode === "goals" ? "chip-active" : ""}" onclick="setPlannerMode('goals')">Goals First</button>
        <button class="chip ${plannerMode === "balanced" ? "chip-active" : ""}" onclick="setPlannerMode('balanced')">Balanced</button>
      </div>
      <button class="btn-primary" style="margin-top:20px;" onclick="handleGeneratePlan()">Generate Plan</button>
    </div>

    ${plan ? `
    <div class="card card-wide">
      <p class="eyebrow-free">Recommendation</p>
      <h3>${plan.subject} — ${plan.chapterName || ""}</h3>
      <p class="muted">Stage: ${STAGE_LABELS[plan.stage]} · ${plan.reason}</p>
      <button class="btn-primary" onclick="handleStartFocusFromRec('${plan.subject}','${plan.chapterId}','${plan.stage}')">Start</button>
    </div>` : ""}
  `;
}

function setPlannerMinutes(m) { plannerMinutes = m; renderPlanner(); }
function setPlannerMode(m) { plannerMode = m; renderPlanner(); }
function handleGeneratePlan() {
  const plan = generatePlan(plannerMinutes, plannerMode);
  renderPlanner();
  if (plan.empty) showToast(plan.message, "info");
}

/* ============ SYLLABUS ============ */
let activeSyllabusSubject = "Physics";
let syllabusSearchTerm = "";

function renderSyllabus() {
  const el = document.getElementById("section-syllabus");
  const subjects = Object.keys(SYLLABUS);

  const chapters = SYLLABUS[activeSyllabusSubject].chapters.filter((ch) =>
    ch.name.toLowerCase().includes(syllabusSearchTerm.toLowerCase())
  );

  el.innerHTML = `
    <div class="card card-wide">
      <input type="text" placeholder="Search chapter or topic…" value="${syllabusSearchTerm}"
        oninput="handleSyllabusSearch(this.value)" class="search-input" />
      <div class="chip-row" style="margin-top:14px;">
        ${subjects.map((s) => `
          <button class="chip ${s === activeSyllabusSubject ? "chip-active" : ""}" onclick="setSyllabusSubject('${s}')">
            ${SYLLABUS[s].icon} ${s} — ${getSubjectProgressPct(s, state.syllabusProgress)}%
          </button>
        `).join("")}
      </div>
    </div>

    <div class="chapter-list">
      ${chapters.map((ch) => renderChapterCard(ch)).join("") || `<p class="muted">No chapters match your search.</p>`}
    </div>
  `;
}

function renderChapterCard(ch) {
  const progress = state.syllabusProgress[ch.id] || emptyChapterProgress();
  const pct = getChapterProgressPct(progress);
  return `
    <div class="card chapter-card">
      <div class="chapter-card-header">
        <h4>${ch.name}</h4>
        <span class="pct-badge">${pct}%</span>
      </div>
      <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
      <div class="stage-row">
        ${STAGES.map((s) => `
          <label class="stage-check">
            <input type="checkbox" ${progress[s] ? "checked" : ""} onchange="handleStageToggle('${ch.id}','${s}')" />
            ${STAGE_LABELS[s]}
          </label>
        `).join("")}
      </div>
    </div>
  `;
}

function setSyllabusSubject(s) { activeSyllabusSubject = s; renderSyllabus(); }
function handleSyllabusSearch(v) { syllabusSearchTerm = v; renderSyllabus(); }

function handleStageToggle(chapterId, stage) {
  if (!state.syllabusProgress[chapterId]) {
    state.syllabusProgress[chapterId] = emptyChapterProgress();
  }
  const wasChecked = state.syllabusProgress[chapterId][stage];
  state.syllabusProgress[chapterId][stage] = !wasChecked;

  if (!wasChecked) {
    awardXP(5, `stage_${chapterId}_${stage}`, `${STAGE_LABELS[stage]} completed`);
    registerStudyActivityForStreak();
  }

  queueCloudSave();
  renderSyllabus();
}

/* ============ GOALS ============ */
function renderGoals() {
  const el = document.getElementById("section-goals");
  const active = state.goals.filter((g) => g.status === "active");
  const completed = state.goals.filter((g) => g.status === "completed");

  el.innerHTML = `
    <div class="card card-wide">
      <button class="btn-primary" onclick="openModal('modal-goal')">+ New Goal</button>
    </div>
    <div class="card card-wide">
      <p class="eyebrow-free">Active (${active.length})</p>
      ${active.map(renderGoalRow).join("") || `<p class="muted">No active goals.</p>`}
    </div>
    <div class="card card-wide">
      <p class="eyebrow-free">Completed (${completed.length})</p>
      ${completed.map(renderGoalRow).join("") || `<p class="muted">Nothing completed yet.</p>`}
    </div>
  `;
}

function renderGoalRow(g) {
  return `
    <div class="goal-row">
      <span class="priority-dot priority-${g.priority}"></span>
      <span class="${g.status === "completed" ? "goal-title-done" : ""}">${g.title}</span>
      <div class="goal-actions">
        ${g.status === "active" ? `<button class="btn-secondary btn-sm" onclick="completeGoal('${g.id}');renderGoals();">Complete</button>` : ""}
        <button class="btn-danger btn-sm" onclick="deleteGoal('${g.id}');renderGoals();">Delete</button>
      </div>
    </div>
  `;
}

function handleCreateGoal() {
  const title = document.getElementById("goal-title-input").value.trim();
  const priority = document.getElementById("goal-priority-input").value;
  if (!title) { showToast("Enter a goal title", "warn"); return; }
  createGoal(title, priority);
  document.getElementById("goal-title-input").value = "";
  closeModal("modal-goal");
  renderGoals();
}

/* ============ QUIZ ============ */
function renderQuiz() {
  const el = document.getElementById("section-quiz");

  if (!activeQuiz) {
    el.innerHTML = `
      <div class="card card-wide">
        <p class="eyebrow-free">Quick Quiz</p>
        <p class="muted">5 syllabus-based MCQs. Score 5/5 for a 60 XP bonus.</p>
        <div class="chip-row">
          <button class="chip" onclick="handleStartQuiz(null)">Mixed</button>
          ${Object.keys(SYLLABUS).map((s) => `<button class="chip" onclick="handleStartQuiz('${s}')">${SYLLABUS[s].icon} ${s}</button>`).join("")}
        </div>
      </div>
    `;
    return;
  }

  if (activeQuiz.quizSubmitted) {
    const correct = activeQuiz.questions.filter((q, i) => activeQuiz.answers[i] === q.answer).length;
    el.innerHTML = `
      <div class="card card-wide quiz-result">
        <h2>${correct}/${activeQuiz.questions.length}</h2>
        <p class="muted">${Math.round((correct / activeQuiz.questions.length) * 100)}% correct</p>
        <button class="btn-primary" onclick="handleRetryQuiz()">Try Another</button>
      </div>
    `;
    return;
  }

  el.innerHTML = `
    <div class="card card-wide">
      ${activeQuiz.questions.map((q, i) => `
        <div class="quiz-question">
          <p class="quiz-q-text">${i + 1}. ${q.q}</p>
          <div class="quiz-options">
            ${q.options.map((opt, oi) => `
              <label class="quiz-option ${activeQuiz.answers[i] === oi ? "quiz-option-selected" : ""}">
                <input type="radio" name="q${i}" ${activeQuiz.answers[i] === oi ? "checked" : ""}
                  onchange="handleSelectAnswer(${i},${oi})" />
                ${opt}
              </label>
            `).join("")}
          </div>
        </div>
      `).join("")}
      <button class="btn-primary" onclick="handleSubmitQuiz()">Submit Quiz</button>
    </div>
  `;
}

function handleStartQuiz(subject) { startNewQuiz(subject); renderQuiz(); }
function handleSelectAnswer(qi, oi) { selectAnswer(qi, oi); renderQuiz(); }
function handleSubmitQuiz() {
  const result = submitQuiz();
  if (!result) return;
  renderQuiz();
}
function handleRetryQuiz() { activeQuiz = null; renderQuiz(); }

/* ============ ANALYTICS ============ */
function renderAnalytics() {
  const el = document.getElementById("section-analytics");
  const a = getAnalyticsSnapshot();

  el.innerHTML = `
    <div class="grid-bento">
      <div class="card card-stat"><span class="stat-label">Focus Time</span><span class="stat-value">${a.totalFocusMinutes}m</span></div>
      <div class="card card-stat"><span class="stat-label">Sessions</span><span class="stat-value">${a.totalSessions}</span></div>
      <div class="card card-stat"><span class="stat-label">Goals Done</span><span class="stat-value">${a.completedGoals}</span></div>
      <div class="card card-stat"><span class="stat-label">Syllabus</span><span class="stat-value">${a.overallSyllabusPct}%</span></div>

      <div class="card card-wide">
        <p class="eyebrow-free">Subject Progress</p>
        ${a.subjectBreakdown.map((s) => `
          <div class="subject-progress-row">
            <span>${s.icon} ${s.subject}</span>
            <div class="progress-bar"><div class="progress-fill" style="width:${s.pct}%"></div></div>
            <span class="pct-badge">${s.pct}%</span>
          </div>
        `).join("")}
      </div>

      <div class="card card-wide">
        <p class="eyebrow-free">Recent Focus Sessions</p>
        ${a.recentSessions.map((s) => `<p class="muted">${s.minutes} min — ${new Date(s.completedAt).toLocaleString()}</p>`).join("") || `<p class="muted">No sessions yet.</p>`}
      </div>
    </div>
  `;
}

/* ============ ASSISTANT (rule-based, transparent) ============ */
function renderAssistant() {
  const el = document.getElementById("section-assistant");
  const rec = getStudyRecommendation(25);
  const weakest = getWeakestSubject();

  el.innerHTML = `
    <div class="card card-wide">
      <p class="eyebrow-free">Study Assistant</p>
      <p class="muted">This assistant is rule-based — it reasons from your syllabus progress, goals, and activity. No external AI is connected.</p>
      <div class="assistant-msg">
        Your weakest subject right now is <strong>${weakest}</strong>.
        ${rec.empty ? rec.message : `I'd suggest <strong>${rec.subject} — ${rec.chapterName}</strong> (${STAGE_LABELS[rec.stage]}) next. ${rec.reason}`}
      </div>
    </div>
  `;
}

/* ============ FOCUS MODAL WIRING ============ */
function handleStartFocusFromRec(subject, chapterId, stage) {
  startFocusSession(plannerMinutes || 25, { subject, chapterId, stage });
  document.getElementById("focus-modal-title").textContent = `${subject} — ${STAGE_LABELS[stage] || ""}`;
  openModal("modal-focus");
  updateFocusModalDisplay();
}

function updateFocusModalDisplay() {
  const display = document.getElementById("focus-time-display");
  const meta = document.getElementById("focus-meta-line");
  const pauseBtn = document.getElementById("focus-pause-btn");
  if (!display) return;
  display.textContent = formatTime(focusTimer.remainingSeconds);
  meta.textContent = focusTimer.meta ? `${focusTimer.meta.subject} · ${STAGE_LABELS[focusTimer.meta.stage] || ""}` : "";
  if (pauseBtn) pauseBtn.textContent = focusTimer.paused ? "Resume" : "Pause";
}

function handleStopFocus() {
  stopFocusSession();
  closeModal("modal-focus");
}

function handleCloseFocusModal() {
  // Closing the modal does not silently discard progress — stop the
  // session explicitly so no partial time is ever mis-recorded.
  if (focusTimer.running) {
    if (confirm("Stop the current focus session?")) {
      stopFocusSession();
      closeModal("modal-focus");
    }
  } else {
    closeModal("modal-focus");
  }
}
