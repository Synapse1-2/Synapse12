/* SYNAPSE 12 — Authentication
   Rule: the app UI is ALWAYS rendered first (see app.js). This file
   only ever updates the auth-specific parts of the screen — it never
   blocks the rest of the app, and it never fails silently.
*/

function signInWithGoogle() {
  if (!firebaseReady || !auth) {
    showToast("Still connecting — try again in a moment", "warn");
    return;
  }

  const provider = new firebase.auth.GoogleAuthProvider();
  setAuthButtonLoading(true);

  auth.signInWithPopup(provider)
    .catch((err) => {
      console.error("Sign-in failed:", err.code, err.message);
      if (err.code === "auth/popup-closed-by-user") {
        showToast("Sign-in cancelled", "info");
      } else if (err.code === "auth/popup-blocked") {
        showToast("Popup blocked — allow popups and try again", "error");
      } else {
        showToast(`Sign-in failed: ${err.message}`, "error");
      }
    })
    .finally(() => setAuthButtonLoading(false));
}

function signOutUser() {
  if (!auth) return;
  auth.signOut().catch((err) => {
    console.error("Sign-out failed:", err.code, err.message);
    showToast("Sign-out failed — try again", "error");
  });
}

function setAuthButtonLoading(isLoading) {
  const btn = document.getElementById("google-signin-btn");
  if (!btn) return;
  btn.disabled = isLoading;
  btn.textContent = isLoading ? "Connecting…" : "Continue with Google";
}

// Called once Firebase is ready (from app.js listener on "firebase-ready").
function watchAuthState() {
  auth.onAuthStateChanged(
    (user) => {
      if (user) {
        onUserSignedIn(user);
      } else {
        onUserSignedOut();
      }
    },
    (err) => {
      console.error("Auth state error:", err.code, err.message);
      showToast("Authentication error — check your connection", "error");
      showAuthScreen();
    }
  );
}

function onUserSignedIn(user) {
  attachCloudSync(user);
  document.getElementById("user-name").textContent = user.displayName || "Student";
  const avatar = document.getElementById("user-avatar");
  if (user.photoURL) {
    avatar.src = user.photoURL;
    avatar.style.display = "inline-block";
  } else {
    avatar.style.display = "none";
  }
  showAppScreen();
  renderCurrentSection(currentSectionId || "dashboard");
}

function onUserSignedOut() {
  detachCloudSync();
  loadLocalState(); // falls back to guest-scoped local state
  showAuthScreen();
}
