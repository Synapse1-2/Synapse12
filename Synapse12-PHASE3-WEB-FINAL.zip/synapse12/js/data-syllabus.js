/* SYNAPSE 12 — Syllabus Data
   Each chapter is keyed by a STABLE id (subject + chapter name based)
   so progress migrates safely across future syllabus edits, per spec:
   "migration based on subject + chapter name — never wipe progress".
*/

const STAGES = ["theory", "derivation", "examples", "pyq", "revision"];
const STAGE_LABELS = {
  theory: "Theory",
  derivation: "Derivation",
  examples: "Examples",
  pyq: "PYQ",
  revision: "Revision"
};

function slugify(subject, chapter) {
  return (subject + "_" + chapter)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

const SYLLABUS_RAW = {
  Physics: {
    icon: "⚡",
    chapters: [
      "Electric Charges and Fields",
      "Electrostatic Potential and Capacitance",
      "Current Electricity",
      "Moving Charges and Magnetism",
      "Magnetism and Matter",
      "Electromagnetic Induction",
      "Alternating Current",
      "Electromagnetic Waves",
      "Ray Optics and Optical Instruments",
      "Wave Optics",
      "Dual Nature of Radiation and Matter",
      "Atoms",
      "Nuclei",
      "Semiconductor Electronics"
    ]
  },
  Chemistry: {
    icon: "🧪",
    chapters: [
      "Solutions",
      "Electrochemistry",
      "Chemical Kinetics",
      "d and f Block Elements",
      "Coordination Compounds",
      "Haloalkanes and Haloarenes",
      "Alcohols, Phenols and Ethers",
      "Aldehydes, Ketones and Carboxylic Acids",
      "Amines",
      "Biomolecules"
    ]
  },
  Maths: {
    icon: "📐",
    chapters: [
      "Relations and Functions",
      "Inverse Trigonometric Functions",
      "Matrices",
      "Determinants",
      "Continuity and Differentiability",
      "Application of Derivatives",
      "Integrals",
      "Application of Integrals",
      "Differential Equations",
      "Vector Algebra",
      "Three Dimensional Geometry",
      "Linear Programming",
      "Probability"
    ]
  },
  Biology: {
    icon: "🧬",
    chapters: [
      "Reproduction in Organisms",
      "Sexual Reproduction in Flowering Plants",
      "Human Reproduction",
      "Reproductive Health",
      "Principles of Inheritance and Variation",
      "Molecular Basis of Inheritance",
      "Evolution",
      "Human Health and Disease",
      "Microbes in Human Welfare",
      "Biotechnology: Principles and Processes",
      "Biotechnology and its Applications",
      "Organisms and Populations",
      "Ecosystem",
      "Biodiversity and Conservation"
    ]
  }
};

// Build a flat, stable structure once.
function buildSyllabusStructure() {
  const structure = {};
  for (const subject in SYLLABUS_RAW) {
    structure[subject] = {
      icon: SYLLABUS_RAW[subject].icon,
      chapters: SYLLABUS_RAW[subject].chapters.map((name) => ({
        id: slugify(subject, name),
        name,
        subject
      }))
    };
  }
  return structure;
}

const SYLLABUS = buildSyllabusStructure();

// progress shape stored per user:
// { [chapterId]: { theory: bool, derivation: bool, examples: bool, pyq: bool, revision: bool } }

function emptyChapterProgress() {
  return { theory: false, derivation: false, examples: false, pyq: false, revision: false };
}

function getChapterProgressPct(progressEntry) {
  if (!progressEntry) return 0;
  const done = STAGES.filter((s) => progressEntry[s]).length;
  return Math.round((done / STAGES.length) * 100);
}

function getSubjectProgressPct(subject, progressMap) {
  const chapters = SYLLABUS[subject].chapters;
  if (!chapters.length) return 0;
  const total = chapters.reduce(
    (sum, ch) => sum + getChapterProgressPct(progressMap[ch.id]),
    0
  );
  return Math.round(total / chapters.length);
}

function getOverallProgressPct(progressMap) {
  const subjects = Object.keys(SYLLABUS);
  const total = subjects.reduce(
    (sum, s) => sum + getSubjectProgressPct(s, progressMap),
    0
  );
  return Math.round(total / subjects.length);
}

// Returns the next incomplete stage for a chapter, or null if fully done.
function getNextStage(progressEntry) {
  if (!progressEntry) return "theory";
  for (const s of STAGES) {
    if (!progressEntry[s]) return s;
  }
  return null;
}
