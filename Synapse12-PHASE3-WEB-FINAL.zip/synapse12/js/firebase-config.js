/* SYNAPSE 12 — Firebase Configuration
   IMPORTANT: This uses the compat SDK (not ES modules) on purpose —
   the project spec explicitly lists "import statements in the middle
   of JS" and "onclick unavailable due to module scope" as previous
   bugs. Compat SDK + plain scripts avoids both.
*/

const firebaseConfig = {
  apiKey: "AIzaSyC7WMMyagbTokhaxLZzZtbyjeIZRr99XTQ",
  authDomain: "synapse-12.firebaseapp.com",
  projectId: "synapse-12",
  storageBucket: "synapse-12.firebasestorage.app",
  messagingSenderId: "95591304742",
  appId: "1:95591304742:web:7eea6a7904627e396908ec"
};

// Initialize immediately but NEVER let this block UI rendering.
// app.js renders the shell first, then calls initFirebase().
let firebaseApp = null;
let auth = null;
let db = null;
let firebaseReady = false;
let firebaseInitError = null;

function initFirebase() {
  try {
    firebaseApp = firebase.initializeApp(firebaseConfig);
    auth = firebase.auth();
    db = firebase.firestore();

    // Reasonable offline cache so local features still work
    // if Firestore is briefly unreachable.
    db.enablePersistence({ synchronizeTabs: true }).catch((err) => {
      console.warn("Firestore persistence not enabled:", err.code);
    });

    firebaseReady = true;
    document.dispatchEvent(new CustomEvent("firebase-ready"));
  } catch (err) {
    firebaseInitError = err;
    console.error("Firebase init failed:", err.code, err.message);
    document.dispatchEvent(new CustomEvent("firebase-error", { detail: err }));
  }
}
