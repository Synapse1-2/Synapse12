/* SYNAPSE 12 — Focus Timer (solo mode)
   Collaborative/room-based Pomodoro (seeing other members studying)
   is a Phase 3 feature that needs the Room system first. This module
   gives every user a working personal focus timer now, which already
   feeds XP, streak, and analytics — nothing here is faked.
*/

let focusTimer = {
  running: false,
  paused: false,
  totalSeconds: 0,
  remainingSeconds: 0,
  intervalId: null,
  meta: null // { subject, chapterId, stage }
};

function startFocusSession(minutes, meta) {
  if (focusTimer.running) return;

  focusTimer = {
    running: true,
    paused: false,
    totalSeconds: minutes * 60,
    remainingSeconds: minutes * 60,
    intervalId: null,
    meta: meta || null
  };

  focusTimer.intervalId = setInterval(() => {
    if (focusTimer.paused) return;
    focusTimer.remainingSeconds -= 1;
    document.dispatchEvent(new CustomEvent("focus-tick"));
    if (focusTimer.remainingSeconds <= 0) {
      completeFocusSession();
    }
  }, 1000);

  document.dispatchEvent(new CustomEvent("focus-started"));
}

function togglePauseFocus() {
  if (!focusTimer.running) return;
  focusTimer.paused = !focusTimer.paused;
  document.dispatchEvent(new CustomEvent("focus-tick"));
}

function stopFocusSession() {
  if (!focusTimer.running) return;
  clearInterval(focusTimer.intervalId);
  focusTimer = { running: false, paused: false, totalSeconds: 0, remainingSeconds: 0, intervalId: null, meta: null };
  document.dispatchEvent(new CustomEvent("focus-stopped"));
}

function completeFocusSession() {
  clearInterval(focusTimer.intervalId);
  const minutes = Math.round(focusTimer.totalSeconds / 60);
  const sessionId = newId();

  state.focusSessions.push({
    id: sessionId,
    minutes,
    subject: focusTimer.meta ? focusTimer.meta.subject : null,
    chapterId: focusTimer.meta ? focusTimer.meta.chapterId : null,
    stage: focusTimer.meta ? focusTimer.meta.stage : null,
    completedAt: Date.now()
  });

  // XP: 2 per minute focused, sourceKey tied to this exact session
  // so it can never be double-awarded on re-render or reload.
  awardXP(minutes * 2, `focus_${sessionId}`, `${minutes} min focus session`);
  registerStudyActivityForStreak();
  queueCloudSave();

  document.dispatchEvent(new CustomEvent("focus-completed", { detail: { minutes } }));
  focusTimer = { running: false, paused: false, totalSeconds: 0, remainingSeconds: 0, intervalId: null, meta: null };
}

function formatTime(totalSeconds) {
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const s = Math.floor(totalSeconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}
