/* SYNAPSE 12 — Gamification (XP, Levels, Streak)
   Anti-duplicate rule: every XP award MUST pass a unique sourceKey.
   If that sourceKey already exists in state.xpLog, the award is
   silently skipped. This is the single mechanism that prevents
   "duplicate quiz XP" and double-counted focus/goal XP (bug #9/#10
   in the project's previous-bugs list).
*/

const LEVELS = [
  { name: "Starter", min: 0 },
  { name: "Focused", min: 200 },
  { name: "Scholar", min: 600 },
  { name: "Legend", min: 1500 }
];

function computeLevel(xp) {
  let current = LEVELS[0];
  for (const lvl of LEVELS) {
    if (xp >= lvl.min) current = lvl;
  }
  const idx = LEVELS.indexOf(current);
  const next = LEVELS[idx + 1] || null;
  return {
    name: current.name,
    xpIntoLevel: xp - current.min,
    xpForNext: next ? next.min - current.min : null,
    nextLevelName: next ? next.name : null,
    progressPct: next ? Math.round(((xp - current.min) / (next.min - current.min)) * 100) : 100
  };
}

// sourceKey MUST be deterministic and unique per real-world event,
// e.g. "quiz_<quizId>", "focus_<sessionId>", "goal_<goalId>",
// "stage_<chapterId>_<stage>".
function awardXP(amount, sourceKey, label) {
  const alreadyAwarded = state.xpLog.some((e) => e.source === sourceKey);
  if (alreadyAwarded) {
    console.warn("XP award skipped (duplicate):", sourceKey);
    return false;
  }

  state.xp += amount;
  state.xpLog.push({ id: newId(), source: sourceKey, amount, at: Date.now() });
  state.level = computeLevel(state.xp).name;

  showToast(`+${amount} XP — ${label}`, "xp");
  queueCloudSave();
  document.dispatchEvent(new CustomEvent("state-updated"));
  return true;
}

// Call this once per calendar day whenever a "meaningful study activity"
// happens (focus session completed, quiz completed, goal completed,
// or a syllabus stage checked). Multiple activities the same day must
// NOT increase the streak multiple times.
function registerStudyActivityForStreak() {
  const today = new Date().toDateString();
  const streak = state.streak;

  if (streak.lastActiveDate === today) {
    return; // already counted today
  }

  if (!streak.lastActiveDate) {
    streak.count = 1;
  } else {
    const last = new Date(streak.lastActiveDate);
    const diffDays = Math.round((new Date(today) - last) / 86400000);
    if (diffDays === 1) {
      streak.count += 1;
    } else if (diffDays > 1) {
      streak.count = 1; // missed day(s) — reset
    }
    // diffDays === 0 already handled above
  }

  streak.lastActiveDate = today;
  queueCloudSave();
  document.dispatchEvent(new CustomEvent("state-updated"));
}
