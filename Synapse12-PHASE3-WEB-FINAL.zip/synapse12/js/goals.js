/* SYNAPSE 12 — Goals */

function createGoal(title, priority) {
  const goal = {
    id: newId(),
    title: title.trim(),
    priority: priority || "medium", // low | medium | high
    status: "active",
    createdAt: Date.now(),
    completedAt: null
  };
  state.goals.unshift(goal);
  queueCloudSave();
  return goal;
}

function editGoal(goalId, updates) {
  const goal = state.goals.find((g) => g.id === goalId);
  if (!goal) return;
  Object.assign(goal, updates);
  queueCloudSave();
}

function completeGoal(goalId) {
  const goal = state.goals.find((g) => g.id === goalId);
  if (!goal || goal.status === "completed") return;

  goal.status = "completed";
  goal.completedAt = Date.now();

  awardXP(30, `goal_${goalId}`, `Goal completed: ${goal.title}`);
  registerStudyActivityForStreak();
  queueCloudSave();
}

function deleteGoal(goalId) {
  state.goals = state.goals.filter((g) => g.id !== goalId);
  queueCloudSave();
}

function getActiveGoals() {
  return state.goals.filter((g) => g.status === "active");
}
