/* SYNAPSE 12 — Smart Planner + "What Should I Study?"
   Real logic, not a random picker: uses actual syllabus progress,
   active goals, and per-subject weakness to recommend a chapter+stage.
*/

function getAllChaptersFlat() {
  const flat = [];
  for (const subject in SYLLABUS) {
    SYLLABUS[subject].chapters.forEach((ch) => flat.push(ch));
  }
  return flat;
}

// "Weak" = lowest average progress % across its chapters.
function getWeakestSubject() {
  let weakest = null;
  let lowestPct = 101;
  for (const subject in SYLLABUS) {
    const pct = getSubjectProgressPct(subject, state.syllabusProgress);
    if (pct < lowestPct) {
      lowestPct = pct;
      weakest = subject;
    }
  }
  return weakest;
}

// Finds the best next chapter+stage to study for a given subject
// (or across all subjects if subject is null), preferring chapters
// that are started-but-incomplete over untouched ones, and
// prioritizing PYQ/Revision on chapters that are otherwise done.
function findBestChapterStage(subjectFilter) {
  const chapters = subjectFilter
    ? SYLLABUS[subjectFilter].chapters
    : getAllChaptersFlat();

  let best = null;
  let bestScore = -1;

  chapters.forEach((ch) => {
    const progress = state.syllabusProgress[ch.id];
    const pct = getChapterProgressPct(progress);
    if (pct === 100) return; // fully done, skip

    const nextStage = getNextStage(progress);
    if (!nextStage) return;

    // Score: prefer partially-done chapters (momentum) over 0%,
    // and give a bump to chapters with pending PYQ specifically.
    let score = pct === 0 ? 10 : 50 - pct; // partially done chapters score higher
    if (nextStage === "pyq") score += 15;
    if (nextStage === "revision") score += 5;

    if (score > bestScore) {
      bestScore = score;
      best = { chapter: ch, stage: nextStage, progressPct: pct };
    }
  });

  return best;
}

function buildReason(pick, mode) {
  const stageLabel = STAGE_LABELS[pick.stage];
  if (pick.progressPct === 0) {
    return `New chapter — starting with ${stageLabel}.`;
  }
  if (pick.stage === "pyq") {
    return `Low progress + pending PYQs.`;
  }
  if (pick.stage === "revision") {
    return `Almost done — just needs Revision.`;
  }
  return `Chapter is ${pick.progressPct}% complete — continuing with ${stageLabel}.`;
}

// mode: "weakest" | "goals" | "balanced"
function generatePlan(availableMinutes, mode) {
  const blockSize = availableMinutes >= 50 ? 50 : 25;
  let pick = null;
  let subjectUsed = null;

  if (mode === "goals" && state.goals.some((g) => g.status === "active")) {
    // Try to match an active goal's subject if the goal title mentions one.
    const activeGoals = state.goals.filter((g) => g.status === "active");
    for (const goal of activeGoals) {
      const matchSubject = Object.keys(SYLLABUS).find((s) =>
        goal.title.toLowerCase().includes(s.toLowerCase())
      );
      if (matchSubject) {
        pick = findBestChapterStage(matchSubject);
        subjectUsed = matchSubject;
        if (pick) break;
      }
    }
  }

  if (!pick && mode === "weakest") {
    subjectUsed = getWeakestSubject();
    pick = findBestChapterStage(subjectUsed);
  }

  if (!pick) {
    // balanced (or fallback): weakest subject still wins ties, but
    // we search across everything rather than forcing one subject.
    pick = findBestChapterStage(null);
    subjectUsed = pick ? pick.chapter.subject : null;
  }

  if (!pick) {
    return {
      empty: true,
      message: "Your syllabus is fully complete! Try Revision on any chapter, or take a Quick Quiz."
    };
  }

  const plan = {
    availableMinutes,
    blockSize,
    mode,
    subject: pick.chapter.subject,
    chapterId: pick.chapter.id,
    chapterName: pick.chapter.name,
    stage: pick.stage,
    reason: buildReason(pick, mode),
    generatedAt: Date.now()
  };

  state.plannerLastPlan = plan;
  queueCloudSave();
  return plan;
}

// Powers the "What should I study now?" dedicated recommendation —
// same engine, framed as a direct answer.
function getStudyRecommendation(availableMinutes) {
  return generatePlan(availableMinutes || 25, "balanced");
}
