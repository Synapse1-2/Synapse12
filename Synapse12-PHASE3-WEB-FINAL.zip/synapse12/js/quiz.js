/* SYNAPSE 12 — Quick Quiz
   quizSubmitted resets on every new quiz start (bug #9/#10 avoidance).
   XP is awarded through awardXP() with a per-quiz-instance sourceKey,
   so a resubmit or re-render can never double-award.
*/

// Small syllabus-grounded question bank. Each question is tagged with
// the subject it belongs to so quizzes stay "syllabus-based" per spec.
const QUESTION_BANK = [
  { subject: "Physics", q: "SI unit of electric charge is:", options: ["Volt", "Coulomb", "Ohm", "Farad"], answer: 1 },
  { subject: "Physics", q: "Electric field lines never do which of these?", options: ["Start from +charge", "End at −charge", "Intersect each other", "Exist in vacuum"], answer: 2 },
  { subject: "Physics", q: "Which device stores electric charge?", options: ["Capacitor", "Resistor", "Inductor", "Diode"], answer: 0 },
  { subject: "Physics", q: "Unit of magnetic flux is:", options: ["Tesla", "Weber", "Henry", "Ampere"], answer: 1 },
  { subject: "Physics", q: "Which phenomenon explains the working of a transformer?", options: ["Photoelectric effect", "Electromagnetic induction", "Nuclear fission", "Total internal reflection"], answer: 1 },
  { subject: "Chemistry", q: "Which colligative property depends on the number of solute particles?", options: ["Density", "Osmotic pressure", "Viscosity", "Color"], answer: 1 },
  { subject: "Chemistry", q: "In electrochemistry, reduction occurs at the:", options: ["Anode", "Cathode", "Salt bridge", "Electrolyte"], answer: 1 },
  { subject: "Chemistry", q: "The rate of a reaction that depends on concentration of one reactant only is:", options: ["Zero order", "First order", "Second order", "Third order"], answer: 1 },
  { subject: "Chemistry", q: "Amines are derivatives of:", options: ["Ammonia", "Methane", "Benzene", "Water"], answer: 0 },
  { subject: "Chemistry", q: "Which functional group defines an alcohol?", options: ["-COOH", "-CHO", "-OH", "-NH2"], answer: 2 },
  { subject: "Maths", q: "The derivative of sin(x) is:", options: ["cos(x)", "-cos(x)", "-sin(x)", "tan(x)"], answer: 0 },
  { subject: "Maths", q: "A square matrix A is invertible only if:", options: ["det(A) = 0", "det(A) ≠ 0", "A is symmetric", "A is diagonal"], answer: 1 },
  { subject: "Maths", q: "∫ 1/x dx equals:", options: ["x²/2", "ln|x| + C", "1/x² + C", "e^x + C"], answer: 1 },
  { subject: "Maths", q: "The order of a differential equation is determined by:", options: ["The highest power", "The highest derivative present", "The number of variables", "The constant terms"], answer: 1 },
  { subject: "Maths", q: "Two vectors are perpendicular if their:", options: ["Cross product is 0", "Dot product is 0", "Magnitudes are equal", "Sum is 0"], answer: 1 },
  { subject: "Biology", q: "Pollination by wind is called:", options: ["Entomophily", "Anemophily", "Hydrophily", "Ornithophily"], answer: 1 },
  { subject: "Biology", q: "DNA replication is described as:", options: ["Conservative", "Semi-conservative", "Dispersive", "Random"], answer: 1 },
  { subject: "Biology", q: "Which organism is commonly used in genetic engineering as a vector?", options: ["E. coli plasmid", "Amoeba", "Paramecium", "Yeast cell wall"], answer: 0 },
  { subject: "Biology", q: "The smallest unit of evolution is:", options: ["Species", "Population", "Individual", "Ecosystem"], answer: 1 },
  { subject: "Biology", q: "Biodiversity hotspots are regions with:", options: ["Low endemism", "High endemism and high threat", "No human impact", "Only marine species"], answer: 1 }
];

let activeQuiz = null; // { id, questions: [...], answers: [], quizSubmitted: false }

function startNewQuiz(subjectFilter) {
  let pool = QUESTION_BANK;
  if (subjectFilter) pool = pool.filter((q) => q.subject === subjectFilter);
  if (pool.length < 5) pool = QUESTION_BANK; // fallback if a subject has too few

  const shuffled = [...pool].sort(() => Math.random() - 0.5).slice(0, 5);

  activeQuiz = {
    id: newId(),
    questions: shuffled,
    answers: new Array(shuffled.length).fill(null),
    quizSubmitted: false // ALWAYS reset on new quiz start
  };
  return activeQuiz;
}

function selectAnswer(questionIndex, optionIndex) {
  if (!activeQuiz || activeQuiz.quizSubmitted) return;
  activeQuiz.answers[questionIndex] = optionIndex;
}

function submitQuiz() {
  if (!activeQuiz || activeQuiz.quizSubmitted) return null;
  activeQuiz.quizSubmitted = true;

  let correct = 0;
  activeQuiz.questions.forEach((q, i) => {
    if (activeQuiz.answers[i] === q.answer) correct++;
  });

  const total = activeQuiz.questions.length;
  // Base 10 XP + 10 per correct answer + a 60 XP bonus for a perfect 5/5.
  let xp = 10 + correct * 10;
  if (correct === total) xp = 60;

  const awarded = awardXP(xp, `quiz_${activeQuiz.id}`, `Quiz: ${correct}/${total}`);

  state.quizHistory.push({
    id: activeQuiz.id,
    score: correct,
    total,
    xpAwarded: awarded ? xp : 0,
    completedAt: Date.now()
  });

  if (correct > 0) registerStudyActivityForStreak();
  queueCloudSave();

  return { correct, total, percent: Math.round((correct / total) * 100), xpAwarded: awarded ? xp : 0 };
}
