/* SYNAPSE 12 — Phase 3: Study Rooms + Members + Presence */
let activeRoomId = localStorage.getItem('synapse12_room_id') || null;
let activeRoom = null;
let roomUnsub = null;
let presenceUnsub = null;
let presenceTimer = null;
let roomBusy = false;

function roomCollection(){ return db.collection('rooms'); }
function presenceCollection(){ return activeRoomId ? roomCollection().doc(activeRoomId).collection('presence') : null; }

function roomCode(){
  const chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s=''; for(let i=0;i<6;i++) s+=chars[Math.floor(Math.random()*chars.length)];
  return s;
}

function escapeHtmlRoom(v){ return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function initials(name){ return (name||'Student').trim().split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase() || 'S'; }
function roomReady(){ return !!(firebaseReady && db && currentUser); }

async function createStudyRoom(){
  if(!roomReady()) return showToast('Google sign-in and Firebase connection are required for rooms','warn');
  if(roomBusy) return; roomBusy=true;
  try{
    const code=roomCode();
    const ref=roomCollection().doc(code);
    const name=(document.getElementById('room-name-input')?.value||'Study Room').trim().slice(0,40)||'Study Room';
    await ref.set({roomCode:code,name,ownerId:currentUser.uid,ownerName:currentUser.displayName||'Student',memberIds:[currentUser.uid],createdAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
    await enterStudyRoom(code);
    closeModal('modal-room');
    showToast('Room created successfully','success');
  }catch(e){ console.error('Create room:',e.code,e.message); showToast(`Could not create room: ${e.message||e.code}`,'error'); }
  finally{ roomBusy=false; }
}

async function joinStudyRoom(){
  if(!roomReady()) return showToast('Google sign-in and Firebase connection are required for rooms','warn');
  if(roomBusy) return; roomBusy=true;
  try{
    const code=(document.getElementById('room-code-input')?.value||'').trim().toUpperCase();
    if(!/^[A-Z0-9]{6}$/.test(code)) return showToast('Enter a valid 6-character room code','warn');
    const ref=roomCollection().doc(code);
    await db.runTransaction(async tx=>{
      const snap=await tx.get(ref);
      if(!snap.exists) throw new Error('Room not found');
      const data=snap.data();
      const members=Array.isArray(data.memberIds)?data.memberIds:[];
      if(members.includes(currentUser.uid)) return;
      if(members.length>=6) throw new Error('This room is full (6/6)');
      tx.update(ref,{memberIds:firebase.firestore.FieldValue.arrayUnion(currentUser.uid),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
    });
    await enterStudyRoom(code);
    closeModal('modal-room');
    showToast('Joined study room','success');
  }catch(e){ console.error('Join room:',e.code,e.message); showToast(`Could not join room: ${e.message||e.code}`,'error'); }
  finally{ roomBusy=false; }
}

async function enterStudyRoom(code){
  leaveRoomListeners();
  activeRoomId=code; localStorage.setItem('synapse12_room_id',code);
  const ref=roomCollection().doc(code);
  roomUnsub=ref.onSnapshot(snap=>{
    if(!snap.exists){ showToast('Room no longer exists','error'); leaveStudyRoom(false); return; }
    activeRoom={id:snap.id,...snap.data()};
    renderRoom();
    updatePresence();
  },err=>{ console.error('Room listener:',err.code,err.message); showToast('Room sync failed — check your connection','warn'); });

  presenceUnsub=presenceCollection().onSnapshot(snap=>{
    const map={}; snap.forEach(d=>map[d.id]=d.data());
    activeRoom={...(activeRoom||{}),presence:map}; renderRoom();
  },err=>console.error('Presence listener:',err.code,err.message));

  await updatePresence();
  clearInterval(presenceTimer);
  presenceTimer=setInterval(updatePresence,20000);
}

async function updatePresence(){
  if(!roomReady()||!activeRoomId) return;
  try{
    await presenceCollection().doc(currentUser.uid).set({uid:currentUser.uid,name:currentUser.displayName||'Student',photoURL:currentUser.photoURL||'',status:'online',activity:'In study room',lastSeen:firebase.firestore.FieldValue.serverTimestamp()},{merge:true});
  }catch(e){ console.warn('Presence update failed:',e.code,e.message); }
}

function leaveRoomListeners(){
  if(roomUnsub) roomUnsub(); if(presenceUnsub) presenceUnsub();
  roomUnsub=null; presenceUnsub=null; clearInterval(presenceTimer); presenceTimer=null;
}

async function leaveStudyRoom(clearSaved=true){
  if(activeRoomId && currentUser && db){
    try{
      const ref=roomCollection().doc(activeRoomId);
      const snap=await ref.get();
      if(snap.exists){
        const data=snap.data();
        if(data.ownerId===currentUser.uid){
          showToast('Room owner cannot leave yet — transfer/close-room management will come in a later phase','warn');
          return;
        }
        await ref.update({memberIds:firebase.firestore.FieldValue.arrayRemove(currentUser.uid),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
        await presenceCollection().doc(currentUser.uid).delete().catch(()=>{});
      }
    }catch(e){ console.error('Leave room:',e.code,e.message); showToast('Could not leave room','error'); return; }
  }
  leaveRoomListeners(); activeRoom=null; activeRoomId=null;
  if(clearSaved) localStorage.removeItem('synapse12_room_id');
  renderRoom();
}

function openRoomManager(){
  const code=activeRoomId||'';
  const html=`<div class="room-manager">
    <div class="room-manager-head"><div><p class="eyebrow-free">Study together</p><h2>Study Room</h2><p class="muted">Create a private 6-person room or join with a code.</p></div></div>
    <div class="room-form-block"><h3>Create a new room</h3><input id="room-name-input" maxlength="40" placeholder="Room name (e.g. PCM Squad)"/><button class="btn-primary" onclick="createStudyRoom()">Create Room</button></div>
    <div class="room-divider">OR</div>
    <div class="room-form-block"><h3>Join a room</h3><input id="room-code-input" maxlength="6" autocapitalize="characters" placeholder="6-character code"/><button class="btn-secondary" onclick="joinStudyRoom()">Join Room</button></div>
    ${code?`<div class="room-current-mini"><span>Saved room: <strong>${escapeHtmlRoom(code)}</strong></span><button class="btn-danger btn-sm" onclick="leaveStudyRoom();closeModal('modal-room')">Leave</button></div>`:''}
  </div>`;
  const modal=document.getElementById('modal-room');
  modal.querySelector('.modal-body').innerHTML=html;
  openModal('modal-room');
}

function renderRoom(){
  const el=document.getElementById('section-room'); if(!el) return;
  if(!currentUser){ el.innerHTML=`<div class="card card-wide"><h2>Study Room</h2><p class="muted">Sign in with Google to create or join a room.</p></div>`; return; }
  if(!activeRoom){
    el.innerHTML=`<div class="grid-bento"><div class="card card-hero card-wide room-hero"><p class="eyebrow-free">Collaborative study</p><h2>Study together, better.</h2><p class="muted">Create a room for up to 6 students, or join your friends with a code.</p><div class="room-actions"><button class="btn-primary" onclick="openRoomManager()">＋ Create / Join Room</button></div></div></div>`;
    return;
  }
  const members=activeRoom.memberIds||[];
  const presence=activeRoom.presence||{};
  const rows=members.map(uid=>{
    const p=presence[uid]||{}; const name=p.name || (uid===currentUser.uid?(currentUser.displayName||'You'):'Student');
    const photo=p.photoURL; const av=photo?`<img src="${escapeHtmlRoom(photo)}" class="room-avatar" alt=""/>`:`<span class="room-avatar room-avatar-fallback">${escapeHtmlRoom(initials(name))}</span>`;
    return `<div class="member-row">${av}<div class="member-main"><strong>${escapeHtmlRoom(name)}${uid===activeRoom.ownerId?' <span class="owner-badge">OWNER</span>':''}</strong><span class="member-status"><i class="presence-dot ${p.status==='online'?'online':''}"></i>${p.status==='online'?'Online':'Offline'}</span></div></div>`;
  }).join('');
  el.innerHTML=`<div class="grid-bento">
    <div class="card card-wide room-hero"><div class="room-topline"><div><p class="eyebrow-free">Study Room</p><h2>${escapeHtmlRoom(activeRoom.name||'Study Room')}</h2><p class="muted">Share this code with your friends</p></div><div class="room-code-badge">${escapeHtmlRoom(activeRoom.roomCode||activeRoom.id)}</div></div><div class="room-actions"><button class="btn-secondary" onclick="navigator.clipboard?.writeText('${escapeHtmlRoom(activeRoom.roomCode||activeRoom.id)}').then(()=>showToast('Room code copied','success'))">Copy Code</button><button class="btn-danger" onclick="leaveStudyRoom()">Leave Room</button></div></div>
    <div class="card card-wide"><div class="room-section-title"><div><p class="eyebrow-free">Members</p><h3>${members.length}/6 students</h3></div><span class="room-live-badge">● Live</span></div><div class="member-list">${rows||'<p class="muted">No members yet.</p>'}</div></div>
    <div class="card card-wide room-next"><p class="eyebrow-free">Next in Phase 3</p><h3>Room collaboration foundation is ready.</h3><p class="muted">Real-time chat and collaborative focus will be layered onto this room in the next phases without changing the room/member foundation.</p></div>
  </div>`;
}

function initRoom(){ renderRoom(); if(activeRoomId && currentUser) enterStudyRoom(activeRoomId).catch(e=>{console.warn('Saved room restore failed',e);activeRoomId=null;localStorage.removeItem('synapse12_room_id');renderRoom();}); }

window.addEventListener('beforeunload',()=>{ try{ clearInterval(presenceTimer); }catch(_){} });
