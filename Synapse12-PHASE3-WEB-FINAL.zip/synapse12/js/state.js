/* SYNAPSE 12 — State & Persistence Layer
   Local storage is ALWAYS the source of truth for instant UI response.
   Firestore syncs in the background when available. This guarantees
   the app is usable even if Firebase is down (per Firebase Failure
   Handling rules) and prevents mixing data between users (per Local
   Persistence rules).
*/

const DEFAULT_STATE = {
  syllabusProgress: {},     // { [chapterId]: {theory,derivation,examples,pyq,revision} }
  goals: [],                // { id, title, priority, status, createdAt, completedAt }
  xp: 0,
  level: "Starter",
  streak: { count: 0, lastActiveDate: null },
  focusSessions: [],        // { id, minutes, subject, chapterId, stage, completedAt }
  quizHistory: [],          // { id, score, total, xpAwarded, completedAt }
  xpLog: [],                // { id, source, amount, at }  -- used to prevent duplicate XP
  plannerLastPlan: null,
  theme: "dark"
};

let currentUser = null;   // firebase user object, or null (guest/local mode)
let state = structuredClone(DEFAULT_STATE);
let firestoreUnsub = null;
let saveTimer = null;

function localKey() {
  const uid = currentUser ? currentUser.uid : "guest";
  return `synapse12_state_${uid}`;
}

function loadLocalState() {
  try {
    const raw = localStorage.getItem(localKey());
    if (raw) {
      const parsed = JSON.parse(raw);
      state = Object.assign(structuredClone(DEFAULT_STATE), parsed);
    } else {
      state = structuredClone(DEFAULT_STATE);
    }
  } catch (err) {
    console.error("Failed to load local state:", err.message);
    state = structuredClone(DEFAULT_STATE);
  }

  // Theme preference is device-level, not user-level, so it survives login switches.
  const theme = localStorage.getItem("synapse12_theme");
  if (theme) state.theme = theme;
}

function saveLocalState() {
  try {
    localStorage.setItem(localKey(), JSON.stringify(state));
  } catch (err) {
    console.error("Failed to save local state:", err.message);
  }
}

// Debounced Firestore sync — avoids excessive writes per Performance rules.
function queueCloudSave() {
  saveLocalState();
  if (!currentUser || !firebaseReady || !db) return;

  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    db.collection("users").doc(currentUser.uid).set(
      { ...state, updatedAt: firebase.firestore.FieldValue.serverTimestamp() },
      { merge: true }
    ).catch((err) => {
      console.error("Cloud save failed:", err.code, err.message);
      showToast("Saved locally — will sync when online", "warn");
    });
  }, 1200);
}

function attachCloudSync(user) {
  currentUser = user;
  loadLocalState();

  if (firestoreUnsub) firestoreUnsub();

  if (!firebaseReady || !db) return;

  const ref = db.collection("users").doc(user.uid);
  firestoreUnsub = ref.onSnapshot(
    (doc) => {
      if (doc.exists) {
        const cloud = doc.data();
        // Merge: cloud is authoritative once it exists, but never drop
        // local-only fields cloud doesn't know about yet.
        state = Object.assign(structuredClone(DEFAULT_STATE), state, cloud);
        saveLocalState();
        document.dispatchEvent(new CustomEvent("state-updated"));
      } else {
        // First login — push current local state up as the initial doc.
        ref.set({ ...state, createdAt: firebase.firestore.FieldValue.serverTimestamp() });
      }
    },
    (err) => {
      console.error("Cloud sync listener failed:", err.code, err.message);
      showToast("Offline — using local data", "warn");
    }
  );
}

function detachCloudSync() {
  if (firestoreUnsub) firestoreUnsub();
  firestoreUnsub = null;
  currentUser = null;
}

// Generic small helper for unique ids without needing a library.
function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
