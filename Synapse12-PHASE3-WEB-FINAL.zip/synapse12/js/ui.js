/* SYNAPSE 12 — UI Utilities
   Modal + Browser Back handling follows the spec exactly:
   - Opening a modal pushes ONE history entry.
   - Back while a modal is open closes the modal (not real navigation).
   - Back with no modal open does normal navigation.
   - We never push more than one history entry per modal open,
     so history can't balloon (bug avoided: "infinite history entries").
*/

let toastTimer = null;

function showToast(message, kind) {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = `toast toast-${kind || "info"}`;
  toast.textContent = message;
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add("toast-visible"));

  setTimeout(() => {
    toast.classList.remove("toast-visible");
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

// ---- Theme ----
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem("synapse12_theme", theme);
  state.theme = theme;
}

function toggleTheme() {
  const next = state.theme === "dark" ? "light" : "dark";
  applyTheme(next);
}

// ---- Modal system ----
let modalStackDepth = 0;

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return;
  modal.classList.add("modal-open");
  modal.setAttribute("aria-hidden", "false");

  history.pushState({ synapseModal: modalId }, "");
  modalStackDepth++;

  document.addEventListener("keydown", escCloseHandler);
}

function closeModal(modalId, skipHistoryBack) {
  const modal = document.getElementById(modalId);
  if (!modal || !modal.classList.contains("modal-open")) return;
  modal.classList.remove("modal-open");
  modal.setAttribute("aria-hidden", "true");
  document.removeEventListener("keydown", escCloseHandler);

  if (!skipHistoryBack && modalStackDepth > 0) {
    modalStackDepth--;
    history.back();
  }
}

function escCloseHandler(e) {
  if (e.key === "Escape") {
    const openEl = document.querySelector(".modal.modal-open");
    if (openEl) closeModal(openEl.id);
  }
}

// Click on the dark overlay (not the modal card itself) closes it.
document.addEventListener("click", (e) => {
  if (e.target.classList.contains("modal") && e.target.classList.contains("modal-open")) {
    closeModal(e.target.id);
  }
});

// Hardware/browser Back handling.
window.addEventListener("popstate", () => {
  const openEl = document.querySelector(".modal.modal-open");
  if (openEl) {
    modalStackDepth = Math.max(0, modalStackDepth - 1);
    closeModal(openEl.id, true); // history already moved back, don't push again
  }
  // If no modal open, this is normal navigation — nothing else to do.
});

// ---- Bottom / side navigation ----
function setActiveSection(sectionId) {
  document.querySelectorAll(".app-section").forEach((el) => {
    el.classList.toggle("section-active", el.id === `section-${sectionId}`);
  });
  document.querySelectorAll(".nav-item").forEach((el) => {
    el.classList.toggle("nav-item-active", el.dataset.section === sectionId);
  });
  renderCurrentSection(sectionId);
}
